package com.ssg.kms.role;

public enum ERole {
	ROLE_USER,
	ROLE_MODERATOR,
	ROLE_ADMIN,
	ROLE_MANAGER
}
