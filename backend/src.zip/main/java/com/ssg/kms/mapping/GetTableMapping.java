package com.ssg.kms.mapping;

import com.ssg.kms.table.Tables;

public interface GetTableMapping {
	Tables getTable();
}
