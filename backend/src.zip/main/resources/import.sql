INSERT INTO role(role) VALUES('ROLE_USER');
INSERT INTO role(role) VALUES('ROLE_MODERATOR');
INSERT INTO role(role) VALUES('ROLE_ADMIN');

INSERT INTO tables(name, description, date, is_public) VALUES('MAIN', 'MAIN', NOW(), true);
