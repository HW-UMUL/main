package com.ssg.kms.mapping;

import com.ssg.kms.chatroom.ChatRoom;

public interface GetChatRoomMapping {
	ChatRoom getChatRoom();
}
