package com.ssg.kms.mapping;

import com.ssg.kms.wiki.Wiki;

public interface GetWikiMapping {
	Wiki getWiki();
}
