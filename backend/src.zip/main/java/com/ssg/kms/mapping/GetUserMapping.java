package com.ssg.kms.mapping;

import com.ssg.kms.user.User;

public interface GetUserMapping {
	User getUser();
}
